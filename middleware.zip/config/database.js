module.exports = {
	'database': 'mongodb://localhost/aimedis_enc_demo'
	// 'database': 'mongodb://85.214.252.27/aimedis'
}
