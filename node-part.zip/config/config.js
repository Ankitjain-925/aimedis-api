module.exports={
	issuer:"Mysoft corp",
	subject:'some@user.com',
	audience:'http://mysoftcorp.in',
	algorithm:"RS256"
}