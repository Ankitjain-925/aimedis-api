module.exports = {
	'paths': 'mongodb://localhost/aimedis'
}