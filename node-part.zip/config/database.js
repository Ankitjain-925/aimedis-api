module.exports = {
	'database': 'mongodb://localhost/aimedis'
}
